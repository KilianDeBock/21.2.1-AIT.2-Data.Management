<?php
$prefix = ['Gent', 'Techno', 'Rock', 'Drop', 'Connect', 'Chill', 'OFFF', 'Tommorow', 'Today', 'Future', 'Pukkel', 'Friday', 'Groove', 'Soul', 'Jazz', 'Pop', 'Schlager', 'Electro', 'Cool', 'Free', 'Motown', 'Pink', 'Yellow', 'Gras' ];
$suffix = [' by night', ' and coctails', ' festival', 'fest', ' beats', 'beat', 'land', ' on the beatch', 'sic', ' summer', 'night', 'united', 'garden', ' music', 'love', 'func', ' sunrize', 'topia', ' space', 'rock', 'town', ' Classics'];
$unavailable = ['Tomorrowland', 'Graspop', 'Gent festival', 'OFFF festival', 'Pinkpop', 'Pukkelpop', 'Jazznight'];
